# Safe Migration Guide

## If You Get "Already Exists" Errors

### Option 1: Clean Up and Re-run (Recommended)

```bash
# 1. Run rollback script first
psql -h your-db.postgres.database.azure.com \
  -U your-username \
  -d your-database \
  -f rollback_license_scanning.sql

# 2. Then run the main migration
psql -h your-db.postgres.database.azure.com \
  -U your-username \
  -d your-database \
  -f optimized_for_existing_customers.sql
```

### Option 2: Run Migration in Sections

If you're getting specific errors, run the migration in sections:

```sql
-- Section 1: Create tables only
CREATE TABLE IF NOT EXISTS customer_licenses (
    -- ... (copy from migration file)
);

CREATE TABLE IF NOT EXISTS license_scans (
    -- ... (copy from migration file)
);

-- Section 2: Create indexes (with IF NOT EXISTS)
CREATE INDEX IF NOT EXISTS idx_customer_licenses_customer_id ON customer_licenses(customer_id);
-- ... etc

-- Section 3: Create triggers
DROP TRIGGER IF EXISTS trigger_customer_licenses_updated_at ON customer_licenses;
CREATE TRIGGER trigger_customer_licenses_updated_at
    BEFORE UPDATE ON customer_licenses
    FOR EACH ROW
    EXECUTE FUNCTION update_customer_licenses_updated_at();

-- Section 4: Create views
CREATE OR REPLACE VIEW v_customers_complete AS
-- ... etc

-- Section 5: Create functions
CREATE OR REPLACE FUNCTION upsert_customer_license_with_sync(...)
-- ... etc

-- Section 6: Enable RLS
DROP POLICY IF EXISTS customer_licenses_isolation ON customer_licenses;
CREATE POLICY customer_licenses_isolation ON customer_licenses
    FOR ALL
    USING (company_id = current_setting('app.current_company_id', true)::UUID);
```

### Option 3: Check What Already Exists

```sql
-- Check if tables exist
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
  AND table_name IN ('customer_licenses', 'license_scans');

-- Check if indexes exist
SELECT indexname 
FROM pg_indexes 
WHERE schemaname = 'public' 
  AND tablename IN ('customer_licenses', 'license_scans');

-- Check if functions exist
SELECT routine_name 
FROM information_schema.routines 
WHERE routine_schema = 'public' 
  AND routine_name LIKE '%license%';

-- Check if views exist
SELECT table_name 
FROM information_schema.views 
WHERE table_schema = 'public' 
  AND table_name LIKE '%customer%';
```

## Common Errors and Solutions

### Error: "relation already exists"

**Solution:** Table already exists. Either:
1. Drop the existing table (WARNING: loses data!)
2. Alter the existing table to add missing columns
3. Use the rollback script

```sql
-- Check table structure
\d customer_licenses

-- Compare with migration to see what's different
```

### Error: "index already exists"

**Solution:** Index already created. The updated migration now uses `CREATE INDEX IF NOT EXISTS` so this shouldn't happen with the new version.

### Error: "function already exists"

**Solution:** Function already created. Use `CREATE OR REPLACE FUNCTION` (already in migration).

### Error: "policy already exists"

**Solution:** Policy already created. The updated migration now uses `DROP POLICY IF EXISTS` first.

## Verify Migration Success

After running migration, verify everything was created:

```sql
-- 1. Check tables
SELECT table_name, 
       (SELECT COUNT(*) FROM information_schema.columns 
        WHERE table_name = t.table_name AND table_schema = 'public') as column_count
FROM information_schema.tables t
WHERE table_schema = 'public' 
  AND table_name IN ('customer_licenses', 'license_scans');

-- Should show:
-- customer_licenses | ~20 columns
-- license_scans     | ~18 columns

-- 2. Check indexes
SELECT tablename, indexname 
FROM pg_indexes 
WHERE schemaname = 'public' 
  AND tablename IN ('customer_licenses', 'license_scans')
ORDER BY tablename, indexname;

-- Should show at least 8 indexes total

-- 3. Check views
SELECT table_name 
FROM information_schema.views 
WHERE table_schema = 'public' 
  AND table_name IN ('v_customers_complete', 'v_expired_licenses', 
                      'v_customers_without_license', 'v_recent_scans');

-- Should show all 4 views

-- 4. Check functions
SELECT routine_name 
FROM information_schema.routines 
WHERE routine_schema = 'public' 
  AND routine_name IN ('upsert_customer_license_with_sync', 'is_license_already_used');

-- Should show both functions

-- 5. Test a simple query
SELECT * FROM v_customers_complete LIMIT 1;
```

## If Something Goes Wrong

### Complete Rollback (WARNING: Deletes all license data!)

```sql
-- 1. Disable RLS
ALTER TABLE customer_licenses DISABLE ROW LEVEL SECURITY;
ALTER TABLE license_scans DISABLE ROW LEVEL SECURITY;

-- 2. Drop everything
DROP TABLE IF EXISTS license_scans CASCADE;
DROP TABLE IF EXISTS customer_licenses CASCADE;
DROP FUNCTION IF EXISTS upsert_customer_license_with_sync CASCADE;
DROP FUNCTION IF EXISTS is_license_already_used CASCADE;
DROP FUNCTION IF EXISTS update_customer_licenses_updated_at CASCADE;

-- 3. Re-run migration
\i optimized_for_existing_customers.sql
```

### Partial Rollback (Keep data, fix objects)

```sql
-- Just drop and recreate functions/views/policies
\i rollback_license_scanning.sql

-- Then re-create them
-- (Copy functions, views, policies sections from main migration)
```

## Best Practice: Transaction Wrapper

For safety, wrap migration in transaction:

```sql
BEGIN;

-- Run migration statements here
\i optimized_for_existing_customers.sql

-- Check results
SELECT COUNT(*) FROM customer_licenses;
SELECT COUNT(*) FROM license_scans;

-- If everything looks good:
COMMIT;

-- If something is wrong:
-- ROLLBACK;
```

## Production Deployment Checklist

- [ ] Backup database before migration
- [ ] Run migration on staging first
- [ ] Verify all objects created successfully
- [ ] Test API endpoints
- [ ] Test mobile app scanning
- [ ] Monitor error logs
- [ ] Have rollback script ready

---

Need help? Check the error message and match it to one of the solutions above.
