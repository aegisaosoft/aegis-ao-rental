-- Rollback/Cleanup Script for License Scanning
-- Use this to clean up if you need to re-run the migration

-- =====================================================
-- 1. DROP POLICIES (if exist)
-- =====================================================
DROP POLICY IF EXISTS customer_licenses_isolation ON customer_licenses;
DROP POLICY IF EXISTS license_scans_isolation ON license_scans;

-- =====================================================
-- 2. DROP TRIGGERS (if exist)
-- =====================================================
DROP TRIGGER IF EXISTS trigger_customer_licenses_updated_at ON customer_licenses;

-- =====================================================
-- 3. DROP FUNCTIONS (if exist)
-- =====================================================
DROP FUNCTION IF EXISTS update_customer_licenses_updated_at();
DROP FUNCTION IF EXISTS upsert_customer_license_with_sync(UUID, UUID, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, DATE, DATE, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, TEXT, VARCHAR, VARCHAR, DATE, BOOLEAN, UUID);
DROP FUNCTION IF EXISTS is_license_already_used(UUID, VARCHAR, VARCHAR, UUID);

-- =====================================================
-- 4. DROP VIEWS (if exist)
-- =====================================================
DROP VIEW IF EXISTS v_customers_complete;
DROP VIEW IF EXISTS v_expired_licenses;
DROP VIEW IF EXISTS v_customers_without_license;
DROP VIEW IF EXISTS v_recent_scans;

-- =====================================================
-- 5. DROP INDEXES (if exist)
-- =====================================================
DROP INDEX IF EXISTS idx_customer_licenses_customer_id;
DROP INDEX IF EXISTS idx_customer_licenses_company_id;
DROP INDEX IF EXISTS idx_customer_licenses_license_number;
DROP INDEX IF EXISTS idx_customer_licenses_expiration_date;
DROP INDEX IF EXISTS idx_customer_licenses_state_issued;

DROP INDEX IF EXISTS idx_license_scans_company_id;
DROP INDEX IF EXISTS idx_license_scans_customer_id;
DROP INDEX IF EXISTS idx_license_scans_scan_date;

-- =====================================================
-- 6. DROP TABLES (if exist)
-- =====================================================
-- WARNING: This will delete all license data!
-- Uncomment only if you want to completely remove the tables

-- DROP TABLE IF EXISTS license_scans CASCADE;
-- DROP TABLE IF EXISTS customer_licenses CASCADE;

-- =====================================================
-- Alternative: Just truncate data, keep tables
-- =====================================================
-- TRUNCATE TABLE license_scans CASCADE;
-- TRUNCATE TABLE customer_licenses CASCADE;

-- =====================================================
-- After running this, you can re-run the main migration
-- =====================================================
